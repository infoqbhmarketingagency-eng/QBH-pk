# QBH Marketing Agency — HTML/CSS/JS

## Files
- index.html — main website
- request.html — YouTube service request form
- style.css — design + logo opening animation
- script.js — intro animation timing
- images/qbh-logo.jpg — QBH logo

## Important
Replace `YOUR_GMAIL@gmail.com` and `YOUR_NUMBER` in `index.html` and `request.html`.

## GitHub Pages
Upload all files to a GitHub repository. In Settings → Pages, choose Deploy from branch, `main`, `/root`.
